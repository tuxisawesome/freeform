import os
import sys
os.system("pip3 install flask")
os.system("pip3 install requests")



print("FreeForm has been installed.")